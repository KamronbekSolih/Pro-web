
CHAR_MAX = 127

CHAR_MIN = -128

DBL_MAX = 1.7976931348623157e+308

DBL_MIN = 2.2250738585072014e-308

FLT_MAX = 3.4028234663852886e+38

FLT_MIN = 1.1754943508222875e-38

INT_MAX = 2147483647

INT_MIN = -2147483648

LLONG_MAX = 9223372036854775807

LLONG_MIN = -9223372036854775808

LONG_MAX = 2147483647

LONG_MIN = -2147483648

PY_SSIZE_T_MAX = 2147483647

PY_SSIZE_T_MIN = -2147483648

SHRT_MAX = 32767

SHRT_MIN = -32768

SIZEOF_PYGC_HEAD = 16

UCHAR_MAX = 255

UINT_MAX = 4294967295

ULLONG_MAX = 18446744073709551615

ULONG_MAX = 4294967295

USHRT_MAX = 65535

__loader__ = "<_frozen_importlib.ExtensionFileLoader object at 0x00C98DD0>"

def _pending_threadfunc(*args,**kw):
    pass

class _test_structmembersType(object):
    pass

def _test_thread_state(*args,**kw):
    pass

def argparsing(*args,**kw):
    pass

def code_newempty(*args,**kw):
    pass

def codec_incrementaldecoder(*args,**kw):
    pass

def codec_incrementalencoder(*args,**kw):
    pass

def crash_no_current_thread(*args,**kw):
    pass

class error(Exception):
    pass

def exception_print(*args,**kw):
    pass

def getargs_B(*args,**kw):
    pass

def getargs_H(*args,**kw):
    pass

def getargs_I(*args,**kw):
    pass

def getargs_K(*args,**kw):
    pass

def getargs_L(*args,**kw):
    pass

def getargs_Z(*args,**kw):
    pass

def getargs_Z_hash(*args,**kw):
    pass

def getargs_b(*args,**kw):
    pass

def getargs_c(*args,**kw):
    pass

def getargs_h(*args,**kw):
    pass

def getargs_i(*args,**kw):
    pass

def getargs_k(*args,**kw):
    pass

def getargs_keyword_only(*args,**kw):
    pass

def getargs_keywords(*args,**kw):
    pass

def getargs_l(*args,**kw):
    pass

def getargs_n(*args,**kw):
    pass

def getargs_p(*args,**kw):
    pass

def getargs_s(*args,**kw):
    pass

def getargs_s_hash(*args,**kw):
    pass

def getargs_s_star(*args,**kw):
    pass

def getargs_tuple(*args,**kw):
    pass

def getargs_u(*args,**kw):
    pass

def getargs_u_hash(*args,**kw):
    pass

def getargs_w_star(*args,**kw):
    pass

def getargs_y(*args,**kw):
    pass

def getargs_y_hash(*args,**kw):
    pass

def getargs_y_star(*args,**kw):
    pass

def getargs_z(*args,**kw):
    pass

def getargs_z_hash(*args,**kw):
    pass

def getargs_z_star(*args,**kw):
    pass

class instancemethod(object):
    pass

def make_exception_with_doc(*args,**kw):
    pass

def make_memoryview_from_NULL_pointer(*args,**kw):
    pass

def parse_tuple_and_keywords(*args,**kw):
    pass

def pytime_object_to_time_t(*args,**kw):
    pass

def pytime_object_to_timespec(*args,**kw):
    pass

def pytime_object_to_timeval(*args,**kw):
    pass

def raise_exception(*args,**kw):
    pass

def raise_memoryerror(*args,**kw):
    pass

def run_in_subinterp(*args,**kw):
    pass

def set_exc_info(*args,**kw):
    pass

def test_L_code(*args,**kw):
    pass

def test_Z_code(*args,**kw):
    pass

def test_capsule(*args,**kw):
    pass

def test_config(*args,**kw):
    pass

def test_datetime_capi(*args,**kw):
    pass

def test_dict_iteration(*args,**kw):
    pass

def test_empty_argparse(*args,**kw):
    pass

def test_k_code(*args,**kw):
    pass

def test_lazy_hash_inheritance(*args,**kw):
    pass

def test_list_api(*args,**kw):
    pass

def test_long_and_overflow(*args,**kw):
    pass

def test_long_api(*args,**kw):
    pass

def test_long_as_double(*args,**kw):
    pass

def test_long_as_size_t(*args,**kw):
    pass

def test_long_long_and_overflow(*args,**kw):
    pass

def test_long_numbits(*args,**kw):
    pass

def test_longlong_api(*args,**kw):
    pass

def test_null_strings(*args,**kw):
    pass

def test_s_code(*args,**kw):
    pass

def test_string_from_format(*args,**kw):
    pass

def test_string_to_double(*args,**kw):
    pass

def test_u_code(*args,**kw):
    pass

def test_unicode_compare_with_ascii(*args,**kw):
    pass

def test_widechar(*args,**kw):
    pass

def test_with_docstring(*args,**kw):
    """This is a pretty normal docstring."""
    pass

def traceback_print(*args,**kw):
    pass

def unicode_aswidechar(*args,**kw):
    pass

def unicode_aswidecharstring(*args,**kw):
    pass

def unicode_encodedecimal(*args,**kw):
    pass

def unicode_transformdecimaltoascii(*args,**kw):
    pass
