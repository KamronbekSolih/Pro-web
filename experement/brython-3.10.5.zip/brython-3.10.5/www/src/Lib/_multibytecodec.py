
class MultibyteIncrementalDecoder(object):

    decode = "<method 'decode' of 'MultibyteIncrementalDecoder' objects>"

    errors = "<attribute 'errors' of 'MultibyteIncrementalDecoder' objects>"

    getstate = "<method 'getstate' of 'MultibyteIncrementalDecoder' objects>"

    reset = "<method 'reset' of 'MultibyteIncrementalDecoder' objects>"

    setstate = "<method 'setstate' of 'MultibyteIncrementalDecoder' objects>"

class MultibyteIncrementalEncoder(object):


    encode = "<method 'encode' of 'MultibyteIncrementalEncoder' objects>"

    errors = "<attribute 'errors' of 'MultibyteIncrementalEncoder' objects>"

    getstate = "<method 'getstate' of 'MultibyteIncrementalEncoder' objects>"

    reset = "<method 'reset' of 'MultibyteIncrementalEncoder' objects>"

    setstate = "<method 'setstate' of 'MultibyteIncrementalEncoder' objects>"

class MultibyteStreamReader(object):


    errors = "<attribute 'errors' of 'MultibyteStreamReader' objects>"

    read = "<method 'read' of 'MultibyteStreamReader' objects>"

    readline = "<method 'readline' of 'MultibyteStreamReader' objects>"

    readlines = "<method 'readlines' of 'MultibyteStreamReader' objects>"

    reset = "<method 'reset' of 'MultibyteStreamReader' objects>"

    stream = "<member 'stream' of 'MultibyteStreamReader' objects>"

class MultibyteStreamWriter(object):


    errors = "<attribute 'errors' of 'MultibyteStreamWriter' objects>"

    reset = "<method 'reset' of 'MultibyteStreamWriter' objects>"

    stream = "<member 'stream' of 'MultibyteStreamWriter' objects>"

    write = "<method 'write' of 'MultibyteStreamWriter' objects>"

    writelines = "<method 'writelines' of 'MultibyteStreamWriter' objects>"

def __create_codec(*args,**kw):
    pass

