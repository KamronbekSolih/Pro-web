for i in range(10000):
    class A:
        def __init__(self, x):
            self.x = x

