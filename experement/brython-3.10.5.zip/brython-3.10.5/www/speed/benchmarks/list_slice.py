a = [1, 2, 3]
for i in range(100000):
    a[:]