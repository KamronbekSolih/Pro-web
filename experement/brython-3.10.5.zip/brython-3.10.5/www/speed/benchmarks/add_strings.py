a, b, c = 'a', 'b', 'c'
for i in range(1000000):
    a + b + c
