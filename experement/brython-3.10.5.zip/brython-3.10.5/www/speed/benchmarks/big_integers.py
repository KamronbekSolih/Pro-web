n = 60
for i in range(10000):
    2 ** n

