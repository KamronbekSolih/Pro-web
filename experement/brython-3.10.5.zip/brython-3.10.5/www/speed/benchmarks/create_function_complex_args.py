for i in range(1000000):
    def f(x, y=1, *args, **kw):
        pass

