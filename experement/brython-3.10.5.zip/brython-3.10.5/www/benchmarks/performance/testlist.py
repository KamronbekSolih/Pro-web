tests=[
{'name': 'bm_ai', 'descr': 'N Queens', 'num_runs': 10},
{'name': 'bm_call_simple', 'descr': 'Test the performance of function calls', 'num_runs': 1},
#todo.. need to install html5lib in site-packages
#{'name': 'bm_html5lib', 'descr': 'Test the performance of the html5lib parser', 'num_runs': 1}

{'name': 'bm_nbody', 'descr': 'Test the performance of the nbody (solar system) emulator', 'num_runs': 1},

{'name': 'bm_regex_compile', 'descr': '', 'num_runs': 1}
]
