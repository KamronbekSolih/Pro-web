module **browser.pydom**
----------------------

<h1>pydom API</h1>

pydom emulates [jQuery](http://www.jquery.com) functionality as much as possible. We are using jQuery's API [documentation](http://api.jquery.com) as a guide 
on how to use pydom.

For examples, check out [pydom](pydom/index.html) documentation.
