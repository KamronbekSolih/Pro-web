from browser import console
import io
import math

print('Hello from Node !!')
